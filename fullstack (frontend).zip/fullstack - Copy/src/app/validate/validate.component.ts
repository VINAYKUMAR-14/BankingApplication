import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.css']
})
export class ValidateComponent implements OnInit {

  details:any;
  data2:any;
  errorMessage:any;
  accountHolderName:string="";
  password:string="";
  constructor(private http :HttpClient,private router: Router) { }

  ngOnInit(): void {
  }
   login(){
    let response=this.http.get("http://localhost:8080/login?accountHolderName="+
    this.accountHolderName+"&&password="+this.password,{responseType:'text' as 'json'})
    response.subscribe((data:any)=>{
      this.data2=data;
      // this.details=JSON.parse(this.data2);
       console.log(data);
      if( this.data2!=null && this.data2 !== ""){
        localStorage.setItem("userDetails",this.data2);
        this.router.navigate(['sender']);
      }
      // if((this.data2==="")||(this.data2==null))
      else{
        this.errorMessage="bad credentials";
        this.accountHolderName="";
        this.password="";
        }
    })
   }
}
