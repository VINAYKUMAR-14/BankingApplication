import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ValidateComponent } from './validate/validate.component';
import { SenderComponent } from './sender/sender.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionhistoryComponent } from './transactionhistory/transactionhistory.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ValidateComponent,
    SenderComponent,
    CheckbalanceComponent,
    TransactionComponent,
    TransactionhistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
