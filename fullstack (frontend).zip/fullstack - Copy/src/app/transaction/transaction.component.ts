import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  constructor(private http:HttpClient,private router:Router) { }
  getData2:any;
  userData:any;
  receiverId:string="";
  amount:any;
  data3:any;
  ngOnInit(): void {
  }
  transactions(){
    this.getData2=localStorage.getItem("userDetails")
    this.userData=JSON.parse(this.getData2);
    let  body={
      'senderId':this.userData.customerId,
      'receiverId':this.receiverId,
      amount:this.amount
    }
    let transferAmount=this.http.put<any>("http://localhost:8080/transfer",body,{responseType:'text' as 'json'});
    transferAmount.subscribe((data:any)=>{
       this.data3=data;
    })
    
  }
  logout(){
    this.router.navigate(['']);
  }
}
