import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transactionhistory',
  templateUrl: './transactionhistory.component.html',
  styleUrls: ['./transactionhistory.component.css']
})
export class TransactionhistoryComponent implements OnInit {

  usertransDetails:any;
  usertransaction:any;
  printData:any=[];
  printData1:any={};
  printData2:any={};
  constructor(private http:HttpClient,private router:Router) {
    this.usertransDetails=localStorage.getItem("userDetails");
    this.usertransaction=JSON.parse(this.usertransDetails);
    let result=this.http.get("http://localhost:8080/transactionhistory?senderId="+this.usertransaction.customerId,{responseType:'text' as 'json'});
    result.subscribe((data:any=[])=>{
      this.printData=data;
      this.printData2=JSON.parse(this.printData);
      console.log(this.printData2);
    })

   }

  ngOnInit(): void {
  }
  logout(){
    this.router.navigate(['']);
  }

}
