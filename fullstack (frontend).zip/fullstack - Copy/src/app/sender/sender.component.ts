import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sender',
  templateUrl: './sender.component.html',
  styleUrls: ['./sender.component.css']
})
export class SenderComponent implements OnInit {

  getData:any;
  receivedData:any;
  data2:any;
  constructor(private router:Router,private http:HttpClient) {
    this.getData=localStorage.getItem("userDetails");
    this.receivedData=JSON.parse(this.getData);
   }

  ngOnInit(): void {
  }
    transfer(){
      this.router.navigate(['transaction']);
    }
    transactionhistories(){
      this.router.navigate(['transactionhistory']);
    }
    logout(){
      this.router.navigate(['']);
    }
    balance(){
      let result1=this.http.get("http://localhost:8080/balance?customerId="+this.receivedData.customerId,{responseType:'text' as 'json'});
      result1.subscribe((data:any)=>{
        this.data2=data;
      })
    }
  
}
