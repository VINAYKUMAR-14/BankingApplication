import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SenderComponent } from './sender/sender.component';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionhistoryComponent } from './transactionhistory/transactionhistory.component';
import { ValidateComponent } from './validate/validate.component';

const routes: Routes = [
{path:'',component:ValidateComponent},
{path:'sender',component:SenderComponent},
{path:'transaction',component:TransactionComponent},
{path:'transactionhistory',component:TransactionhistoryComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
