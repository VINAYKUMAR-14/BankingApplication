package com.training.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {

	@Id
	String customerId;
	String accountHolderName;
	String password;
	double balance;
	String od;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String customerId, String accountHolderName, String password, double balance, String od) {
		super();
		this.customerId = customerId;
		this.accountHolderName = accountHolderName;
		this.password = password;
		this.balance = balance;
		this.od = od;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", accountHolderName=" + accountHolderName + ", password="
				+ password + ", balance=" + balance + ", od=" + od + "]";
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getOd() {
		return od;
	}
	public void setOd(String od) {
		this.od = od;
	}
	
	
	
	
	
	
	
}
