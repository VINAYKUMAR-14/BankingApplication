package com.training.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.demo.model.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer,String> {

	Customer findByAccountHolderName(String accountHolderName);

	Customer findByCustomerId(String senderId);
	

}
