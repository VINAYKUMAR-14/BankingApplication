package com.training.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.demo.model.BlackList;
import com.training.demo.model.Customer;
import com.training.demo.model.Transaction;
import com.training.demo.repo.BlackListRepo;
import com.training.demo.repo.CustomerRepo;
import com.training.demo.repo.TransactionRepo;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepo customerrepo;
	
	@Autowired
	TransactionRepo transrepo;
	
	@Autowired
	BlackListRepo blackrepo;
	

	public Customer retrive(String accountHolderName, String password) {
		try {
		Customer customer=customerrepo.findByAccountHolderName(accountHolderName);
		BlackList blaclistdata=blackrepo.findByCustomerId(customer.getCustomerId());
		System.out.println(customer);
		if((customer!=null) && (customer.getPassword().equals(password))) {
			return customer;

		
	}
	//else {
		customer=null;
		return customer;
	//}
	//return null;
}
		catch(Exception e) {
			return null;
		}
					
	}


	public String transferAmount(String senderId,String receiverId, double amount) {
		Customer sender =customerrepo.findByCustomerId(senderId);
		System.out.println(sender.getCustomerId());
		String senderName=sender.getAccountHolderName();
		
		BlackList bUser=blackrepo.findByCustomerId(receiverId);
		try {
			Customer receiver=customerrepo.findByCustomerId(receiverId);
			System.out.println(receiver.getCustomerId());
			String receiverName=receiver.getAccountHolderName();
			if(amount<0)
				return "please enter  a valid amount";
			if(sender.getBalance()>=amount) {
				if(bUser.getBl().equals("no")) {
					sender.setBalance(sender.getBalance()-amount);
					receiver.setBalance(receiver.getBalance()+amount);
					customerrepo.save(sender);
					customerrepo.save(receiver);
					Transaction t=new Transaction(senderId,senderName,receiverId,receiverName,amount);
					transrepo.save(t);
					return "Transaction successful";
				}
				else
					return "Receiver is in blackList cannot transfer the amount";
			}
			else if(sender.getBalance()<amount) {
				if(sender.getOd().equals("yes")) {
					if(bUser.getBl().equals("no")) {
						sender.setBalance(sender.getBalance()-amount);
						receiver.setBalance(receiver.getBalance()+amount);
						customerrepo.save(sender);
						customerrepo.save(receiver);
						Transaction t=new Transaction(senderId,senderName,receiverId,receiverName,amount);
						transrepo.save(t);
						return "Transaction successful but with od facility";
					}//for blackList=no
					else
						return "Receiver is in blackList cannot transfer the amount";
				}//for od=yes
				else
					return "Insufficicent balance";
			}//for amount>balance
		}//for not null
		catch(Exception e) {
		return "receiver not found";
		}
		return null;
		
	}


	public List<Transaction> transactionamount(String customerId) {
		// TODO Auto-generated method stub
		return transrepo.findBySenderId(customerId);
	}


	public double balance(String customerId) {
		// TODO Auto-generated method stub
		Customer user=customerrepo.findByCustomerId(customerId);
		return user.getBalance();
		
	}

}
