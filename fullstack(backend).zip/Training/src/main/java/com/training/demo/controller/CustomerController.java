package com.training.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.demo.dto.CustomerDto;
import com.training.demo.model.Customer;
import com.training.demo.model.Transaction;
import com.training.demo.service.CustomerService;
import java.util.*;
@RestController
@CrossOrigin(value="*")
public class CustomerController {
	
	Customer c;
	
	@Autowired
	CustomerService customerservice;
	
	@RequestMapping("/login")
	public Customer Login(@RequestParam String accountHolderName,@RequestParam String password) {
		c=customerservice.retrive(accountHolderName, password);
		return customerservice.retrive(accountHolderName,password);
		
	}
	@PutMapping("/transfer")
	public String Transfer(@RequestBody CustomerDto dto) {
		return customerservice.transferAmount(dto.getSenderId(),dto.getReceiverId(),dto.getAmount());
		
	}
	@GetMapping("/transactionhistory")
		public List<Transaction> transactionhistory(@RequestParam String senderId){
			return customerservice.transactionamount(senderId);
			
		}
	@GetMapping("/balance")
	public double checkBalance(@RequestParam String customerId) {
		return customerservice.balance(customerId);
	}
	}
	

