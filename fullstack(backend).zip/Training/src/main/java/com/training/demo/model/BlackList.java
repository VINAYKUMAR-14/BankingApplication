package com.training.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BlackList {
	
	@Id
	String customerId;
	String bl;
	public BlackList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BlackList(String customerId, String bl) {
		super();
		this.customerId = customerId;
		this.bl = bl;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getBl() {
		return bl;
	}
	public void setBl(String bl) {
		this.bl = bl;
	}
	@Override
	public String toString() {
		return "BlackList [customerId=" + customerId + ", bl=" + bl + "]";
	}
	
	

}
